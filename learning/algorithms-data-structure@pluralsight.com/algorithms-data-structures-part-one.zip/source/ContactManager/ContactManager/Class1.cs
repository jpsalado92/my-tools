﻿using System;

namespace ContactManager
{
    public class Class1
    {
    }
}
