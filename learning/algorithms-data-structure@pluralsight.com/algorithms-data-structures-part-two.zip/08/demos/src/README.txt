Projects:

* Queue.Common

Contains the Heap, IQueue, Job, and QueueEmptyException types.

* Queue.Client

A sample application that uses the monitor locking and reader/writer priority queue types without any caller side locking

* Queue.Client.Locking

A sample application that uses the queue types with client side locking

* Queue.Client.NonLocking

A sample application that uses the queue without any caller synchronization

* Queue.Locking

A queue type that uses monitor locking to provide method level thread safety

* Queue.ReadWriteLock

A queue type that uses ReaderWriterLockSlim to provide method level thread safety

* Queue.NonLocking

A queue type that does not provide any thread safety

